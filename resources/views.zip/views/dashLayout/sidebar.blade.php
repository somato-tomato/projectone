<ul class="list-unstyled accordion-menu">
    <li class="sidebar-title">
        Dasbor
    </li>
    <li>
        <a href="{{ route('dashboard') }}"><i class="fas fa-dashboard"></i>Dasbor</a>
    </li>
    <li>
        <a href="{{ route('site.sc') }}"><i class="fas fa-cog"></i>Konfigurasi Situs</a>
    </li>
    <li>
        <a href="{{ route('team.index') }}"><i class="fas fa-user-plus"></i>Team</a>
    </li>
    <li>
        <a href="{{ route('portofolio.index') }}"><i class="fas fa-th-list"></i>Portofolio</a>
    </li>
    <li>
        <a href="{{ route('site.t') }}"><i class="fas fa-users"></i>Testimoni</a>
    </li>
    <li>
        <a href="{{ route('package.index') }}"><i class="fas fa-hand-holding-heart"></i>Package</a>
    </li>
    <li>
        <a href="{{ route('clientlogo.index') }}"><i class="fas fa-chart-line"></i>Client Logo</a>
    </li>
</ul>
